package com.codeoftheweb.salvo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {

	    SpringApplication.run(SalvoApplication.class, args);
	}

	/*@Bean
	public PasswordEncoder passwordEncoder() {
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}*/

	@Bean
	public CommandLineRunner initData(PlayerRepository playerRepository,
									  GameRepository gameRepository,
									  GamePlayerRepository gamePlayerRepository,
									  ShipRepository shipRepository, SalvoRepository salvoRepository){
		return (args) -> {
			Player player1 = new Player("j.bauer@ctu.gov.ar");
			Player player2 = new Player("c.obrian@ctu.gov");
			Player player3 = new Player("kim_bauer@gmail.com");
			Player player4 = new Player("t.almeida@ctu.gov");

			// to save a couple of players
			//playerRepository.save(new Player("Jack Bauer"));
			//playerRepository.save(new Player("Chloe O'Brian"));
			//playerRepository.save(new Player("Kim Bauer"));
			//playerRepository.save(new Player("Tony Almeida"));

			playerRepository.save(player1);
			playerRepository.save(player2);
			playerRepository.save(player3);
			playerRepository.save(player4);


			Date date1 = new Date();
			Date date2 = Date.from(date1.toInstant().plusSeconds(3600));
			Date date3 = Date.from(date2.toInstant().plusSeconds(3000));

			Game game1 = new Game(date1);
			Game game2 = new Game(date2);
			Game game3 = new Game(date3);

			gameRepository.save(game1);
			gameRepository.save(game2);
			gameRepository.save(game3);

			GamePlayer gp1 = new GamePlayer(date1,game1,player1);
			GamePlayer gp2 = new GamePlayer(date1, game1,player2);

			GamePlayer gp3 = new GamePlayer(date2, game2,player1);
			GamePlayer gp4 = new GamePlayer(date2, game2,player2);

			GamePlayer gp5 = new GamePlayer(date3, game3,player2);
			GamePlayer gp6 = new GamePlayer(date3, game3,player4);

			gamePlayerRepository.save(gp1);
			gamePlayerRepository.save(gp2);

			gamePlayerRepository.save(gp3);
			gamePlayerRepository.save(gp4);

			gamePlayerRepository.save(gp5);
			gamePlayerRepository.save(gp6);

			List<String> location1 = new ArrayList<>(Arrays.asList("H2","H3","H4"));
			List<String> location2 = new ArrayList<>(Arrays.asList("E1", "F1", "G1"));
			List<String> location3 = new ArrayList<>(Arrays.asList("B4", "B5"));
			List<String> location4 = new ArrayList<>(Arrays.asList("B5", "C5", "D5"));

			List<String> location5 = new ArrayList<>(Arrays.asList("F1", "F2"));
			List<String> location6 = new ArrayList<>(Arrays.asList("C6", "C7"));
			List<String> location7 = new ArrayList<>(Arrays.asList("A2", "A3", "A4"));
			List<String> location8 = new ArrayList<>(Arrays.asList("G6", "H6"));

			Ship ship1 = new Ship(Ship.ShipType.DESTROYER, location1,gp1);
			Ship ship2 = new Ship(Ship.ShipType.SUBMARINE, location2,gp1);
			Ship ship3 = new Ship(Ship.ShipType.PATROL_BOAT, location3,gp1);

			Ship ship4 = new Ship(Ship.ShipType.DESTROYER, location4,gp2);
			Ship ship5 = new Ship(Ship.ShipType.CARRIER, location5,gp2);
			Ship ship6 = new Ship(Ship.ShipType.SUBMARINE, location6,gp2);

			Ship ship7 = new Ship(Ship.ShipType.PATROL_BOAT, location7,gp3);
			Ship ship8 = new Ship(Ship.ShipType.CARRIER, location8,gp3);
			Ship ship9 = new Ship(Ship.ShipType.BATTLESHIP, location1,gp3);

			Ship ship10 = new Ship(Ship.ShipType.BATTLESHIP, location2,gp4);
			Ship ship11 = new Ship(Ship.ShipType.SUBMARINE, location3,gp4);
			Ship ship12 = new Ship(Ship.ShipType.PATROL_BOAT, location4,gp4);

			shipRepository.saveAll(Arrays.asList(ship1,ship2,ship3,ship4,ship5,ship6,ship7,ship8,ship9,ship10,ship11,ship12));

		};
	}

}

/*	@Configuration
	class WebSecurityConfiguration extends GlobalAuthenticationConfigurerAdapter {

		@Autowired
		PlayerRepository playerRepository;

		@Override
		public void init(AuthenticationManagerBuilder auth) throws Exception {
			auth.userDetailsService(inputName-> {
				Player player = playerRepository.findByUserName(inputName);
				if (player != null) {
					return new Player(player.getUserName(), player.getPassword(),
						AuthorityUtils.createAuthorityList("USER"));
				} else {
					throw new UsernameNotFoundException("Unknown user: " + inputName);
				}
			});
		}
	}*/
