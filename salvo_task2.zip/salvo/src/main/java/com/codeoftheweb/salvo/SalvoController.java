package com.codeoftheweb.salvo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.management.ObjectName;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;


@RestController
@RequestMapping("/api/")
public class SalvoController {

    @Autowired
    private GameRepository gameRepository;
    @Autowired
    private PlayerRepository playerRepository;
    @Autowired
    private GamePlayerRepository gamePlayerRepository;

   // @RequestMapping("/players")
   // public List<Object> getPlayers(){
   //     return playerRepository.findAll().stream().collect(toList());}

    @RequestMapping("/games")
    public List<Object> getGameId(){
        return gameRepository.findAll()
                .stream()
                .map(Game::makeGameDTO)
                .collect(toList());
    }
}

