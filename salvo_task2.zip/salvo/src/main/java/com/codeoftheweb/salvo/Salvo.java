package com.codeoftheweb.salvo;

import javax.persistence.ElementCollection;

public class Salvo {
    private long id;

    private int turn;

//@ElementCollection

}
