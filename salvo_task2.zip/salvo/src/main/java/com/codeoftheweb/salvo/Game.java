package com.codeoftheweb.salvo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.*;

import static java.util.stream.Collectors.toList;

@Entity
public class Game {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
  @GenericGenerator(name="native",strategy="native")
  private Long id;
  private Date creationDate;

  @OneToMany(mappedBy="game", fetch=FetchType.EAGER)
  private List<GamePlayer> gamePlayers ;

  public Game() {
  }

  public Game(Date creationDate) {
    this.creationDate = creationDate;
  }

  public Long getId() {
    return id;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public List<GamePlayer> getGamePlayers() {return gamePlayers;}

  public void addGamePlayer(GamePlayer gamePlayer){
    gamePlayer.setGame(this);
    gamePlayers.add(gamePlayer);
  }

  @JsonIgnore
  public List<Player> getPlayers(){
    return gamePlayers.stream().map(sub -> sub.getPlayer()).collect(toList());
  }

  public static Map<String, Object> makeGameDTO(Game game){
      Map<String, Object> dto = new LinkedHashMap<String, Object>();
      dto.put("id", game.getId());
      dto.put("creationDate", game.getCreationDate());
      dto.put("gamePlayers", game.getGamePlayers().stream().map(GamePlayer::makeGamePlayerDTO));
      return dto;
  }
}
